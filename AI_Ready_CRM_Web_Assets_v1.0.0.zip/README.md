# AI Ready CRM WEB配信用画像 v1.0.0

- OGP: `og/column/`（PNG 1200×630）
- 本文図: `article-images/column/ai-ready-crm-data-structure/`（WebP、最大幅1600px）
- alt・寸法・SHA-256: `manifest.json`
